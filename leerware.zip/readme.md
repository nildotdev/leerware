﻿# ASPHYXIA: CS2

## Table of Contents :scroll:
- [About](#about)
- [Contact](#contact)
- [Credits](#credits)
- [Reminder](#reminder)
- [License](#license)

## About :information_source:
- Asphyxia is a base that was intended to be a starting point. It is not a cheat itself, but rather a framework for building your own cheat.
- C++ version: 20

## Credits
- [imgui](https://github.com/ocornut/imgui) - framework
- [freetype](https://freetype.org/) - font rasterizer
- [minhook](https://github.com/TsudaKageyu/minhook) - hooking library
- [qo0:csgo](https://github.com/rollraw/qo0-csgo) - where this base is inspired
- [unknowncheats](https://www.unknowncheats.me/) - for helping building this base

## Reminder
- this project is for educational purposes only.
- it will now be more focus on the 'base' rather than the 'cheat' itself.

  [✓] ESP - basic esp feature like: name, hp, armor... (comes with interactive menu preview, not draggable)
  
  [✓] CHAMS - basic chams system
  
  [✓] AIMBOT - simple head aimbot with smoothing

## License

- This project is licensed under the [MIT License](https://opensource.org/licenses/mit-license.php) - see the [LICENSE](LICENSE) file for details.
